 
package opencv_1;

import java.awt.BorderLayout;
import org.opencv.core.Core;

 
public class Opencv_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.out.println(Core.VERSION);
        
    }
    
}
